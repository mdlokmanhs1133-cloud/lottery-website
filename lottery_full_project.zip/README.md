# Lottery Website — Full Project (Demo)

This repository contains a demo lottery website (frontend + Node.js backend) with:
- Stripe Checkout integration (create session endpoint + webhook)
- SQLite ticket storage
- Provable-fair commit-reveal seed flow
- Simple admin JWT login (demo)
- Static frontend served from `/public`

**Important:** This project is a demo. Do NOT accept real money until you:
- Configure secure admin credentials
- Add HTTPS and secure hosting
- Verify legal compliance for lotteries in your jurisdiction
- Test webhooks in Stripe test mode

## Quick local run (dev)
1. Copy `.env.example` to `.env` and fill keys.
2. `npm install`
3. `node server.js`
4. Use Stripe CLI to forward webhooks in dev:
   `stripe listen --forward-to localhost:3000/webhook`

## Deploy
Recommended: Railway, Render, Fly.io, DigitalOcean App Platform.
See `deploy_railway.sh` for a sample script.

