require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const crypto = require('crypto');
const sqlite3 = require('sqlite3').verbose();
const Stripe = require('stripe');
const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

const app = express();

// Serve static frontend
app.use(express.static('public'));

// Use JSON body for most routes, but webhook needs raw body
app.use(bodyParser.json());

// Simple SQLite DB for demo (tickets, seeds)
const db = new sqlite3.Database('./data.db');
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS tickets(id TEXT PRIMARY KEY, name TEXT, note TEXT, time INTEGER)`);
  db.run(`CREATE TABLE IF NOT EXISTS seeds(id INTEGER PRIMARY KEY AUTOINCREMENT, seed TEXT, seed_hash TEXT, created_at INTEGER, revealed_at INTEGER)`);
});

// Utility
function randomId(len=8){ return crypto.randomBytes(len).toString('hex').slice(0,len); }

// Create Stripe Checkout session
app.post('/create-checkout-session', async (req, res) => {
  try {
    const { name, qty, price, note } = req.body;
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [{
        price_data: {
          currency: 'usd',
          product_data: { name: 'Lottery ticket' },
          unit_amount: Math.round((price || 1) * 100)
        },
        quantity: qty || 1
      }],
      mode: 'payment',
      success_url: (process.env.SUCCESS_URL || 'https://example.com/success') + '?session_id={CHECKOUT_SESSION_ID}',
      cancel_url: (process.env.CANCEL_URL || 'https://example.com/cancel'),
      metadata: { name: name || 'Anonymous', note: note || '' }
    });
    res.json({ url: session.url });
  } catch (err) {
    console.error('create-checkout-session error', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Stripe webhook (raw body)
app.post('/webhook', bodyParser.raw({ type: 'application/json' }), (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Webhook signature verification failed.', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const metadata = session.metadata || {};
    // Derive quantity from session if possible
    const qty = session.amount_total && session.amount_total > 0 ? (session.display_items ? session.display_items.reduce((s,i)=>s+(i.quantity||1),0) : 1) : 1;
    for (let i = 0; i < qty; i++) {
      const id = randomId(8);
      db.run('INSERT INTO tickets(id,name,note,time) VALUES(?,?,?,?)', [id, metadata.name || 'Anonymous', metadata.note || '', Date.now()]);
    }
    console.log('Issued', qty, 'tickets for session', session.id);
  }

  res.json({ received: true });
});

// Admin auth simple (env-based password -> hash). For demo we accept a single ADMIN_PASSWORD env var and compare.
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123'; // set strong pass in prod
const JWT_SECRET = process.env.JWT_SECRET || 'change_this_secret';

// Admin login - returns token (demo)
app.post('/admin/login', bodyParser.json(), async (req, res) => {
  const { username, password } = req.body;
  // In production, store hashed password in env or DB. For demo, compare directly.
  if (!password) return res.status(400).json({ error: 'Missing password' });
  if (password !== ADMIN_PASSWORD) return res.status(401).json({ error: 'Invalid credentials' });
  const token = jwt.sign({ user: username || 'admin' }, JWT_SECRET, { expiresIn: '8h' });
  res.json({ token });
});

// Middleware to protect admin endpoints
function requireAdmin(req, res, next) {
  const auth = req.headers.authorization || '';
  const m = auth.match(/^Bearer (.+)$/);
  if (!m) return res.status(401).json({ error: 'Missing token' });
  const token = m[1];
  try {
    const data = jwt.verify(token, JWT_SECRET);
    req.user = data;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

// Admin: create seed (commit)
app.post('/admin/create-seed', requireAdmin, (req, res) => {
  const seed = crypto.randomBytes(32).toString('hex');
  const seed_hash = crypto.createHash('sha256').update(seed).digest('hex');
  db.run('INSERT INTO seeds(seed,seed_hash,created_at) VALUES(?,?,?)', [seed, seed_hash, Date.now()], function(err) {
    if (err) return res.status(500).send('DB error');
    res.json({ id: this.lastID, seed_hash });
  });
});

// Admin: reveal seed
app.post('/admin/reveal-seed', requireAdmin, (req, res) => {
  const { id } = req.body;
  db.get('SELECT * FROM seeds WHERE id=?', [id], (err, row) => {
    if (err || !row) return res.status(404).send('Not found');
    db.run('UPDATE seeds SET revealed_at=? WHERE id=?', [Date.now(), id]);
    res.json({ seed: row.seed, seed_hash: row.seed_hash });
  });
});

// Admin: run draw (deterministic using seed)
app.post('/admin/draw', requireAdmin, (req, res) => {
  const { seed_id, winners = 1 } = req.body;
  db.all('SELECT * FROM tickets', [], (err, tickets) => {
    if (err) return res.status(500).send('DB error');
    if (tickets.length === 0) return res.status(400).send('No tickets');
    db.get('SELECT * FROM seeds WHERE id=?', [seed_id], (err, seedRow) => {
      if (err || !seedRow) return res.status(404).send('Seed not found');
      const seed = seedRow.seed;
      function randIndex(i) {
        const h = crypto.createHmac('sha256', seed).update(String(i)).digest('hex');
        return parseInt(h.slice(0, 8), 16) % tickets.length;
      }
      const chosen = [];
      const used = new Set();
      let i = 0;
      while (chosen.length < Math.min(winners, tickets.length)) {
        const idx = randIndex(i);
        if (!used.has(idx)) { used.add(idx); chosen.push(tickets[idx]); }
        i++;
      }
      res.json({ winners: chosen, seed_hash: seedRow.seed_hash, seed_revealed: !!seedRow.revealed_at });
    });
  });
});

// Admin endpoints: list tickets, export CSV
app.get('/admin/tickets', requireAdmin, (req, res) => {
  db.all('SELECT * FROM tickets', [], (err, rows) => {
    if (err) return res.status(500).send('DB error');
    res.json(rows);
  });
});

app.get('/admin/export-tickets', requireAdmin, (req, res) => {
  db.all('SELECT * FROM tickets', [], (err, rows) => {
    if (err) return res.status(500).send('DB error');
    const csv = ['id,name,note,time'].concat(rows.map(r => [r.id, r.name, (r.note||''), r.time].map(v => '"'+String(v).replace(/"/g,'""')+'"').join(','))).join('\n');
    res.setHeader('Content-disposition', 'attachment; filename=tickets.csv');
    res.setHeader('Content-Type', 'text/csv');
    res.send(csv);
  });
});

// Simple health
app.get('/health', (req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log('Server running on', PORT));
