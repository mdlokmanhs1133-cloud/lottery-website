# Simple Lottery Demo

This is a minimal demo of the lottery frontend (no payments). 
Files:
- public/index.html — demo UI storing tickets in browser localStorage
- server.js — optional static server to serve the public folder

To run locally:
1. npm install
2. node server.js
3. Open http://localhost:3000
